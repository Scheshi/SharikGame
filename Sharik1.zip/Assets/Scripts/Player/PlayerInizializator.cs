﻿using UnityEngine;


namespace SharikGame
{
    public class PlayerInizializator
    {
        public PlayerInizializator(PersonData playerData, Transform startPointTransform)
        {
            var player = GameObject.Instantiate(playerData.gameObject, startPointTransform.position, Quaternion.identity);
            var playerModel = new PlayerModel(playerData.PlayerStruct);
            var playerController = new PlayerController(playerModel, player);
            var playerView = new PlayerView(playerController, player);
            ServiceLocator.SetDepencity(player);
            ServiceLocator.SetDepencity(playerModel);
            ControllersUpdater.AddUpdate(playerView);
        }
    }
}
