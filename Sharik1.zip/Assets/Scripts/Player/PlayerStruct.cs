﻿using System;


namespace SharikGame
{
    [Serializable]
    public struct PlayerStruct
    {
        public int LifeCount;
        public float Speed;
    }
}
