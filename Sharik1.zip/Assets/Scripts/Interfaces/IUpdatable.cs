﻿namespace SharikGame
{
    public interface IUpdatable
    {

    }
}
