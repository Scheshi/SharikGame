﻿namespace SharikGame
{
    public interface IFrameUpdatable : IUpdatable
    {
        void UpdateTick();
    }
}
