﻿namespace SharikGame
{
    public interface IFixedUpdatable : IUpdatable
    {
        void FixedUpdateTick();
    }
}
