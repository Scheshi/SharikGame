﻿namespace SharikGame
{
    public interface IInteractable
    {
        void Interacte();
    }
}
