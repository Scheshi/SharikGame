﻿namespace SharikGame
{
    public interface IModel
    {
       float Speed { get; }
    }
}
