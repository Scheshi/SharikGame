﻿using System;


namespace SharikGame
{
    [Serializable]
    public struct EnemyStruct
    {
        public int Damage;
        public float Speed;
    }
}
